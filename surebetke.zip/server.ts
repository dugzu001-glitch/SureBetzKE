import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import "dotenv/config";
import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import cookieParser from "cookie-parser";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Database Setup
let db: any;
try {
  db = new Database("surebetke.db");
  console.log("Database connected successfully");
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE,
      password TEXT,
      recovery_phrase TEXT,
      role TEXT DEFAULT 'user',
      is_premium INTEGER DEFAULT 0,
      premium_until DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS access_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      date DATE DEFAULT CURRENT_DATE,
      count INTEGER DEFAULT 0,
      UNIQUE(user_id, date)
    );

    CREATE TABLE IF NOT EXISTS upgrade_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      status TEXT DEFAULT 'pending',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id)
    );
  `);

  // Migration: Ensure all columns exist in users table
  const tableInfo = db.prepare("PRAGMA table_info(users)").all();
  const columns = tableInfo.map((col: any) => col.name);
  
  if (!columns.includes('recovery_phrase')) {
    console.log("Migrating: Adding recovery_phrase to users");
    db.exec("ALTER TABLE users ADD COLUMN recovery_phrase TEXT");
  }
  if (!columns.includes('role')) {
    console.log("Migrating: Adding role to users");
    db.exec("ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'user'");
  }
  if (!columns.includes('is_premium')) {
    console.log("Migrating: Adding is_premium to users");
    db.exec("ALTER TABLE users ADD COLUMN is_premium INTEGER DEFAULT 0");
  }
  if (!columns.includes('premium_until')) {
    console.log("Migrating: Adding premium_until to users");
    db.exec("ALTER TABLE users ADD COLUMN premium_until DATETIME");
  }
} catch (err) {
  console.error("DATABASE ERROR:", err);
}

const JWT_SECRET = process.env.JWT_SECRET || "super-secret-key";

async function startServer() {
  console.log("Starting SureBetKE Server...");
  const app = express();
  const PORT = 3000;

  app.use(express.json());
  app.use(cookieParser());

  app.get("/api/test", (req, res) => {
    res.json({ message: "API is working" });
  });

  // Logging middleware
  app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
    next();
  });

  // Auth Middleware
  const authenticate = (req: any, res: any, next: any) => {
    const token = req.cookies.token;
    if (!token) return res.status(401).json({ error: "Unauthorized" });
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      req.user = decoded;
      next();
    } catch (err) {
      res.status(401).json({ error: "Invalid token" });
    }
  };

  // Auth Routes
  app.post("/api/auth/signup", async (req, res) => {
    const { email, password, recovery_phrase } = req.body;
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const hashedPhrase = await bcrypt.hash(recovery_phrase.toLowerCase(), 10);
      const stmt = db.prepare("INSERT INTO users (email, password, recovery_phrase) VALUES (?, ?, ?)");
      const result = stmt.run(email, hashedPassword, hashedPhrase);
      res.json({ success: true, userId: result.lastInsertRowid });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  app.post("/api/auth/reset-password", async (req, res) => {
    const { email, recovery_phrase, new_password } = req.body;
    const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email) as any;
    if (!user || !user.recovery_phrase) {
      return res.status(404).json({ error: "User not found or recovery not set" });
    }
    
    const phraseMatch = await bcrypt.compare(recovery_phrase.toLowerCase(), user.recovery_phrase);
    if (!phraseMatch) {
      return res.status(401).json({ error: "Invalid recovery phrase" });
    }

    const hashedNewPassword = await bcrypt.hash(new_password, 10);
    db.prepare("UPDATE users SET password = ? WHERE id = ?").run(hashedNewPassword, user.id);
    res.json({ success: true });
  });

  app.post("/api/auth/login", async (req, res) => {
    const { email, password } = req.body;
    const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email) as any;
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: "Invalid credentials" });
    }
    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: "7d" });
    res.cookie("token", token, { httpOnly: true, secure: true, sameSite: "none" });
    res.json({ success: true, user: { id: user.id, email: user.email, role: user.role, is_premium: user.is_premium } });
  });

  app.post("/api/auth/admin-login", async (req, res) => {
    const { password } = req.body;
    if (password === (process.env.ADMIN_PASSWORD || "1965@Davis!Davis$")) {
      const token = jwt.sign({ id: 0, email: "admin@surebetke.com", role: "admin" }, JWT_SECRET, { expiresIn: "1d" });
      res.cookie("token", token, { httpOnly: true, secure: true, sameSite: "none" });
      res.json({ success: true, user: { id: 0, email: "admin@surebetke.com", role: "admin" } });
    } else {
      res.status(401).json({ error: "Invalid admin password" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    res.clearCookie("token");
    res.json({ success: true });
  });

  app.get("/api/auth/me", (req, res) => {
    console.log("GET /api/auth/me called");
    const token = req.cookies.token;
    if (!token) return res.json({ user: null });
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      const user = db.prepare("SELECT id, email, role, is_premium, premium_until FROM users WHERE id = ?").get(decoded.id) as any;
      
      // Check if premium expired
      if (user && user.is_premium && new Date(user.premium_until) < new Date()) {
        db.prepare("UPDATE users SET is_premium = 0 WHERE id = ?").run(user.id);
        user.is_premium = 0;
      }
      
      res.json({ user });
    } catch (err) {
      res.json({ user: null });
    }
  });

  // Subscription Route
  app.post("/api/subscribe", authenticate, (req: any, res) => {
    // Check if there's already a pending request
    const existing = db.prepare("SELECT * FROM upgrade_requests WHERE user_id = ? AND status = 'pending'").get(req.user.id);
    if (existing) {
      return res.json({ success: true, message: "Request already pending" });
    }
    
    db.prepare("INSERT INTO upgrade_requests (user_id) VALUES (?)").run(req.user.id);
    res.json({ success: true, message: "Upgrade request submitted" });
  });

  // Admin Routes
  const adminOnly = (req: any, res: any, next: any) => {
    const token = req.cookies.token;
    if (!token) return res.status(401).json({ error: "Unauthorized" });
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      if (decoded.role !== 'admin') return res.status(403).json({ error: "Forbidden" });
      req.user = decoded;
      next();
    } catch (err) {
      res.status(401).json({ error: "Invalid token" });
    }
  };

  app.get("/api/admin/upgrade-requests", adminOnly, (req, res) => {
    const requests = db.prepare(`
      SELECT r.*, u.email 
      FROM upgrade_requests r 
      JOIN users u ON r.user_id = u.id 
      WHERE r.status = 'pending'
      ORDER BY r.created_at DESC
    `).all();
    res.json(requests);
  });

  app.post("/api/admin/approve-upgrade", adminOnly, (req, res) => {
    const { requestId } = req.body;
    const request = db.prepare("SELECT * FROM upgrade_requests WHERE id = ?").get(requestId) as any;
    
    if (!request) return res.status(404).json({ error: "Request not found" });

    const premiumUntil = new Date();
    premiumUntil.setDate(premiumUntil.getDate() + 7); // 7 days

    db.transaction(() => {
      db.prepare("UPDATE users SET is_premium = 1, premium_until = ? WHERE id = ?").run(premiumUntil.toISOString(), request.user_id);
      db.prepare("UPDATE upgrade_requests SET status = 'approved' WHERE id = ?").run(requestId);
    })();

    res.json({ success: true });
  });

  app.post("/api/admin/reject-upgrade", adminOnly, (req, res) => {
    const { requestId } = req.body;
    db.prepare("UPDATE upgrade_requests SET status = 'rejected' WHERE id = ?").run(requestId);
    res.json({ success: true });
  });

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Global Error Handler
  app.use((err: any, req: any, res: any, next: any) => {
    console.error("SERVER ERROR:", err);
    res.status(500).json({ error: "Internal Server Error" });
  });

  // Mock data for arbitrage opportunities
  app.get("/api/surebets", (req, res) => {
    console.log("GET /api/surebets called");
    const token = req.cookies.token;
    let user: any = null;
    if (token) {
      try {
        const decoded = jwt.verify(token, JWT_SECRET) as any;
        user = db.prepare("SELECT * FROM users WHERE id = ?").get(decoded.id);
      } catch (err) {}
    }

    const mockSurebets = [
      {
        id: "1",
        event: "Gor Mahia vs AFC Leopards",
        league: "Kenya Premier League",
        startTime: new Date(Date.now() + 3600000).toISOString(),
        market: "1X2",
        profit: 3.45,
        outcomes: [
          { label: "1", bookmaker: "Betika", odds: 2.15, url: "https://www.betika.com" },
          { label: "X", bookmaker: "Odibets", odds: 3.40, url: "https://odibets.com" },
          { label: "2", bookmaker: "Sportybet", odds: 4.80, url: "https://www.sportybet.com/ke/" }
        ]
      },
      {
        id: "2",
        event: "Tusker FC vs Bandari",
        league: "Kenya Premier League",
        startTime: new Date(Date.now() + 7200000).toISOString(),
        market: "Over/Under 2.5",
        profit: 1.82,
        outcomes: [
          { label: "Over", bookmaker: "Mozzartbet", odds: 2.05, url: "https://www.mozzartbet.co.ke/" },
          { label: "Under", bookmaker: "22bet", odds: 2.02, url: "https://22bet.co.ke/" }
        ]
      },
      {
        id: "3",
        event: "KCB vs Posta Rangers",
        league: "Kenya Premier League",
        startTime: new Date(Date.now() + 10800000).toISOString(),
        market: "BTTS",
        profit: 2.15,
        outcomes: [
          { label: "Yes", bookmaker: "Betway", odds: 1.95, url: "https://betway.com/g/en/sports" },
          { label: "No", bookmaker: "1xbet", odds: 2.18, url: "https://1xbet.co.ke/" }
        ]
      },
      {
        id: "4",
        event: "Ulinzi Stars vs Mathare United",
        league: "Kenya Premier League",
        startTime: new Date(Date.now() + 14400000).toISOString(),
        market: "1X2",
        profit: 4.12,
        outcomes: [
          { label: "1", bookmaker: "22bet", odds: 2.30, url: "https://22bet.co.ke/" },
          { label: "X", bookmaker: "Mozzartbet", odds: 3.10, url: "https://www.mozzartbet.co.ke/" },
          { label: "2", bookmaker: "Betika", odds: 4.20, url: "https://www.betika.com" }
        ]
      }
    ];

    // Limit free users
    if (!user || user.is_premium === 0) {
      // Free users only see the first one
      return res.json(mockSurebets.slice(0, 1));
    }

    res.json(mockSurebets);
  });

  // Articles
  app.get("/api/articles/:slug", (req, res) => {
    const { slug } = req.params;
    const articles: any = {
      "how-it-works": {
        title: "How It Works",
        content: "Arbitrage betting, or 'surebets', is a technique where you place bets on all possible outcomes of an event across different bookmakers. Because bookmakers have different odds, you can find situations where the combined implied probability is less than 100%, guaranteeing a profit regardless of the outcome."
      },
      "arbitrage-guide": {
        title: "Arbitrage Guide",
        content: "1. Find a surebet on SureBetKE.\n2. Use our calculator to determine stakes.\n3. Open all bookmaker sites.\n4. Place all bets as quickly as possible to avoid odds changes."
      },
      "risk-management": {
        title: "Risk Management",
        content: "While mathematically guaranteed, risks include: odds changes before all bets are placed, bookmaker errors (voided bets), and account limitations. Always double-check odds before confirming."
      }
    };
    res.json(articles[slug] || { error: "Not found" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting Vite in middleware mode...");
    const vite = await createViteServer({
      server: { 
        middlewareMode: true,
        host: '0.0.0.0',
        port: 3000,
        hmr: false
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`SureBetKE Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
