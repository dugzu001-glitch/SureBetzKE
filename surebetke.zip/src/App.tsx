import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  Filter, 
  RefreshCw, 
  Search, 
  ChevronRight, 
  Calculator as CalcIcon,
  Zap,
  Clock,
  Globe,
  ExternalLink,
  User,
  LogOut,
  Lock,
  MessageCircle,
  Send,
  ShieldCheck,
  BookOpen,
  Info,
  AlertTriangle,
  CreditCard,
  X,
  Copy,
  Check
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Surebet, Outcome } from './types';
import { BOOKMAKERS_DATA, MARKETS } from './constants';
import { ArbitrageCalculator } from './components/ArbitrageCalculator';

const BOOKMAKERS = BOOKMAKERS_DATA.map(b => b.name);

interface UserData {
  id: number;
  email: string;
  role: string;
  is_premium: number;
  premium_until?: string;
}

export default function App() {
  const [surebets, setSurebets] = useState<Surebet[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSurebet, setSelectedSurebet] = useState<Surebet | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [minProfit, setMinProfit] = useState(0);
  const [user, setUser] = useState<UserData | null>(null);
  const [authModal, setAuthModal] = useState<'login' | 'signup' | 'admin' | 'forgot' | null>(null);
  const [articleModal, setArticleModal] = useState<string | null>(null);
  const [articleContent, setArticleContent] = useState<{ title: string; content: string } | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [recoveryPhrase, setRecoveryPhrase] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [error, setError] = useState('');
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const [upgradeRequests, setUpgradeRequests] = useState<any[]>([]);
  const [isAdminView, setIsAdminView] = useState(false);

  const fetchUpgradeRequests = async () => {
    try {
      const res = await fetchWithRetry('/api/admin/upgrade-requests');
      const data = await res.json();
      setUpgradeRequests(data);
    } catch (err) {
      console.error('Failed to fetch upgrade requests:', err);
    }
  };

  const approveUpgrade = async (requestId: number) => {
    try {
      const res = await fetch('/api/admin/approve-upgrade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requestId })
      });
      if (res.ok) fetchUpgradeRequests();
    } catch (err) {
      console.error('Failed to approve upgrade:', err);
    }
  };

  const rejectUpgrade = async (requestId: number) => {
    try {
      const res = await fetch('/api/admin/reject-upgrade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requestId })
      });
      if (res.ok) fetchUpgradeRequests();
    } catch (err) {
      console.error('Failed to reject upgrade:', err);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const fetchWithRetry = async (url: string, options: RequestInit = {}, retries = 3): Promise<Response> => {
    try {
      const res = await fetch(url, options);
      if (!res.ok && retries > 0) {
        await new Promise(r => setTimeout(r, 1000));
        return fetchWithRetry(url, options, retries - 1);
      }
      return res;
    } catch (err) {
      if (retries > 0) {
        await new Promise(r => setTimeout(r, 1000));
        return fetchWithRetry(url, options, retries - 1);
      }
      throw err;
    }
  };

  const fetchUser = async () => {
    try {
      const res = await fetchWithRetry('/api/auth/me');
      const data = await res.json();
      setUser(data.user);
    } catch (err) {
      console.error('Failed to fetch user:', err);
    }
  };

  const fetchSurebets = async () => {
    setLoading(true);
    try {
      const response = await fetchWithRetry('/api/surebets');
      const data = await response.json();
      setSurebets(data);
    } catch (error) {
      console.error('Failed to fetch surebets:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchArticle = async (slug: string) => {
    try {
      const res = await fetchWithRetry(`/api/articles/${slug}`);
      const data = await res.json();
      setArticleContent(data);
      setArticleModal(slug);
    } catch (err) {
      console.error('Failed to fetch article:', err);
    }
  };

  useEffect(() => {
    fetchUser();
    fetchSurebets();
    const interval = setInterval(fetchSurebets, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (user?.role === 'admin' && isAdminView) {
      fetchUpgradeRequests();
    }
  }, [user, isAdminView]);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const endpoint = authModal === 'login' ? '/api/auth/login' : 
                     authModal === 'signup' ? '/api/auth/signup' : 
                     authModal === 'forgot' ? '/api/auth/reset-password' :
                     '/api/auth/admin-login';
    
    try {
      const body = authModal === 'admin' ? { password } : 
                   authModal === 'signup' ? { email, password, recovery_phrase: recoveryPhrase } :
                   authModal === 'forgot' ? { email, recovery_phrase: recoveryPhrase, new_password: newPassword } :
                   { email, password };

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (data.success) {
        if (authModal === 'signup') {
          setAuthModal('login');
          setError('Account created! Please log in.');
        } else if (authModal === 'forgot') {
          setAuthModal('login');
          setError('Password reset successful! Please log in.');
        } else {
          setUser(data.user);
          setAuthModal(null);
          fetchSurebets();
        }
      } else {
        setError(data.error || 'Authentication failed');
      }
    } catch (err) {
      setError('An error occurred');
    }
  };

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    setUser(null);
    fetchSurebets();
  };

  const handleUpgrade = async () => {
    try {
      const res = await fetch('/api/subscribe', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        fetchUser();
        fetchSurebets();
        setShowUpgradeModal(false);
      }
    } catch (err) {
      console.error('Upgrade failed:', err);
    }
  };

  const [showContacts, setShowContacts] = useState<{ [key: string]: boolean }>({});

  const toggleContact = (id: string) => {
    setShowContacts(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const filteredSurebets = surebets.filter(sb => 
    sb.event.toLowerCase().includes(searchTerm.toLowerCase()) &&
    sb.profit >= minProfit
  );

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white">
              <TrendingUp className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-black tracking-tight text-slate-900 leading-none">SureBet<span className="text-emerald-600">KE</span></h1>
                <div className="flex items-center gap-1 px-1.5 py-0.5 bg-emerald-100 rounded text-[8px] font-black text-emerald-700 uppercase tracking-widest animate-pulse">
                  <span className="w-1 h-1 bg-emerald-600 rounded-full" />
                  Live
                </div>
              </div>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-[0.2em] leading-none mt-1">East African Arbitrage</p>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-6">
            <nav className="flex items-center gap-4 text-sm font-medium text-slate-600">
              <button 
                onClick={() => setIsAdminView(false)} 
                className={`${!isAdminView ? 'text-emerald-600 border-b-2 border-emerald-600' : 'hover:text-emerald-600'} py-5 transition-colors`}
              >
                Surebets
              </button>
              {user?.role === 'admin' && (
                <button 
                  onClick={() => setIsAdminView(true)} 
                  className={`${isAdminView ? 'text-emerald-600 border-b-2 border-emerald-600' : 'hover:text-emerald-600'} py-5 transition-colors`}
                >
                  Admin Dashboard
                </button>
              )}
              <button onClick={() => fetchArticle('how-it-works')} className="hover:text-emerald-600 py-5 transition-colors">How it Works</button>
              <button onClick={() => fetchArticle('arbitrage-guide')} className="hover:text-emerald-600 py-5 transition-colors">Guide</button>
            </nav>
            <div className="h-6 w-px bg-slate-200" />
            
            {user ? (
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-3 px-3 py-1.5 bg-slate-50 rounded-2xl border border-slate-100">
                  <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center text-white text-xs font-bold shadow-inner">
                    {user.email.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-slate-900 leading-none">{user.email.split('@')[0]}</span>
                    <span className={`text-[9px] uppercase tracking-tighter font-black mt-0.5 ${user.is_premium ? 'text-emerald-600' : 'text-slate-400'}`}>
                      {user.is_premium ? 'Premium' : 'Free'}
                    </span>
                  </div>
                </div>
                <button 
                  onClick={handleLogout} 
                  className="p-2.5 hover:bg-red-50 rounded-xl text-slate-400 hover:text-red-600 transition-all active:scale-95"
                  title="Logout"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button onClick={() => setAuthModal('login')} className="px-4 py-2 text-sm font-semibold text-slate-600 hover:text-slate-900">Log In</button>
                <button onClick={() => setAuthModal('signup')} className="px-4 py-2 bg-slate-900 text-white rounded-lg text-sm font-semibold hover:bg-slate-800 transition-colors">Sign Up</button>
              </div>
            )}

            {!user?.is_premium && (
              <button 
                onClick={() => setShowUpgradeModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-emerald-50 text-emerald-700 rounded-lg text-sm font-semibold hover:bg-emerald-100 transition-colors"
              >
                <Zap className="w-4 h-4 fill-current" />
                Upgrade Pro
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full p-4 md:p-6">
        {!user ? (
          <div className="py-20 text-center space-y-12">
            <div className="max-w-3xl mx-auto space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-100 text-emerald-700 rounded-full text-xs font-bold uppercase tracking-wider"
              >
                <Zap className="w-3 h-3 fill-current" />
                Live Arbitrage Scanning Active
              </motion.div>
              <h2 className="text-5xl md:text-7xl font-black text-slate-900 tracking-tight leading-[0.9]">
                Guaranteed Profits. <br />
                <span className="text-emerald-600 italic font-serif">Zero Risk.</span>
              </h2>
              <p className="text-xl text-slate-500 leading-relaxed max-w-2xl mx-auto">
                Join SureBetKE today to access the most advanced football arbitrage dashboard in East Africa. 
                Start earning guaranteed returns from every match.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              <button 
                onClick={() => setAuthModal('signup')}
                className="w-full sm:w-auto px-10 py-5 bg-emerald-600 text-white rounded-2xl font-black text-xl hover:bg-emerald-700 transition-all shadow-2xl shadow-emerald-600/30 hover:-translate-y-1 active:scale-[0.98]"
              >
                Get Started Now
              </button>
              <button 
                onClick={() => setAuthModal('login')}
                className="w-full sm:w-auto px-10 py-5 bg-white text-slate-900 border-2 border-slate-200 rounded-2xl font-black text-xl hover:bg-slate-50 transition-all hover:-translate-y-1 active:scale-[0.98]"
              >
                Sign In
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-16">
              {[
                { icon: Zap, title: "Real-time Odds", desc: "We scan 20+ bookmakers every second to find the best arbitrage opportunities." },
                { icon: ShieldCheck, title: "Guaranteed ROI", desc: "Our mathematical models ensure you profit regardless of the final score." },
                { icon: Globe, title: "Regional Focus", desc: "Optimized for Kenyan, Ugandan, and Tanzanian bookmakers and payment systems." }
              ].map((feature, i) => (
                <div key={i} className="p-8 bg-white rounded-3xl border border-slate-100 shadow-sm hover:shadow-xl transition-all duration-300 text-left group">
                  <div className="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center text-emerald-600 mb-6 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                    <feature.icon className="w-7 h-7" />
                  </div>
                  <h3 className="font-black text-xl text-slate-900 mb-3">{feature.title}</h3>
                  <p className="text-slate-500 leading-relaxed">{feature.desc}</p>
                </div>
              ))}
            </div>
          </div>
        ) : isAdminView && user.role === 'admin' ? (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-3xl font-black tracking-tight text-slate-900">Admin Dashboard</h2>
                <p className="text-sm text-slate-500">Manage user upgrade requests and verify payments.</p>
              </div>
              <button 
                onClick={fetchUpgradeRequests}
                className="flex items-center gap-2 px-5 py-2.5 bg-white border border-slate-200 rounded-2xl text-sm font-bold hover:bg-slate-50 transition-all shadow-sm active:scale-95"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                Refresh List
              </button>
            </div>

            <div className="bg-white rounded-3xl border border-slate-200 shadow-xl shadow-slate-200/50 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50/50 border-b border-slate-200">
                      <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">User Details</th>
                      <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Request Time</th>
                      <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Status</th>
                      <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Management</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {upgradeRequests.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-8 py-24 text-center">
                          <div className="max-w-xs mx-auto space-y-4">
                            <div className="w-16 h-16 bg-slate-50 rounded-3xl flex items-center justify-center mx-auto text-slate-200">
                              <ShieldCheck className="w-8 h-8" />
                            </div>
                            <div>
                              <h3 className="font-bold text-slate-900">All caught up!</h3>
                              <p className="text-sm text-slate-400 leading-relaxed">No pending upgrade requests at the moment. New requests will appear here.</p>
                            </div>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      upgradeRequests.map((req) => (
                        <tr key={req.id} className="hover:bg-slate-50/50 transition-colors group">
                          <td className="px-8 py-6">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center text-slate-400 font-bold group-hover:bg-emerald-100 group-hover:text-emerald-600 transition-colors">
                                {req.email.charAt(0).toUpperCase()}
                              </div>
                              <div>
                                <div className="font-bold text-slate-900">{req.email}</div>
                                <div className="text-[10px] text-slate-400 font-mono uppercase tracking-tighter">User ID: #{req.user_id}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-8 py-6">
                            <div className="text-sm text-slate-600 font-medium">{new Date(req.created_at).toLocaleDateString()}</div>
                            <div className="text-xs text-slate-400">{new Date(req.created_at).toLocaleTimeString()}</div>
                          </td>
                          <td className="px-8 py-6">
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-amber-50 text-amber-700 rounded-lg text-[10px] font-black uppercase tracking-wider border border-amber-100">
                              <span className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-pulse" />
                              {req.status}
                            </span>
                          </td>
                          <td className="px-8 py-6 text-right space-x-3">
                            <button 
                              onClick={() => approveUpgrade(req.id)}
                              className="px-5 py-2 bg-emerald-600 text-white rounded-xl text-xs font-black hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/20 active:scale-95"
                            >
                              Approve
                            </button>
                            <button 
                              onClick={() => rejectUpgrade(req.id)}
                              className="px-5 py-2 bg-white text-red-600 border border-red-100 rounded-xl text-xs font-black hover:bg-red-50 transition-all active:scale-95"
                            >
                              Reject
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Sidebar Filters */}
            <aside className="lg:col-span-1 space-y-6">
              <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="font-bold flex items-center gap-2">
                    <Filter className="w-4 h-4 text-slate-400" />
                    Filters
                  </h2>
                  <button 
                    onClick={fetchSurebets}
                    className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
                    title="Refresh"
                  >
                    <RefreshCw className={`w-4 h-4 text-slate-400 ${loading ? 'animate-spin' : ''}`} />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 block">Search Event</label>
                    <div className="relative">
                      <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input 
                        type="text" 
                        placeholder="e.g. Gor Mahia"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 block">Min. Profit (%)</label>
                    <input 
                      type="range" 
                      min="0" 
                      max="10" 
                      step="0.1"
                      value={minProfit}
                      onChange={(e) => setMinProfit(Number(e.target.value))}
                      className="w-full accent-emerald-600"
                    />
                    <div className="flex justify-between text-xs font-mono text-slate-500 mt-1">
                      <span>0%</span>
                      <span className="text-emerald-600 font-bold">{minProfit}%</span>
                      <span>10%</span>
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 block">Bookmakers</label>
                    <div className="max-h-48 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
                      {BOOKMAKERS.map(bookie => (
                        <label key={bookie} className="flex items-center gap-2 cursor-pointer group">
                          <input type="checkbox" defaultChecked className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500" />
                          <span className="text-sm text-slate-600 group-hover:text-slate-900 transition-colors">{bookie}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-slate-900 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden">
                <div className="relative z-10">
                  <h3 className="font-bold text-lg mb-2">Live Alerts</h3>
                  <p className="text-slate-400 text-xs mb-4">Get instant desktop notifications for new high-profit surebets.</p>
                  <button className="w-full py-2 bg-white text-slate-900 rounded-xl text-sm font-bold hover:bg-slate-100 transition-colors">
                    Enable Notifications
                  </button>
                </div>
                <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-emerald-500/20 rounded-full blur-2xl" />
              </div>
            </aside>

            {/* Main Feed */}
            <section className="lg:col-span-3 space-y-4">
              <div className="flex items-center justify-between mb-2 px-2">
                <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-widest">
                  Live Opportunities ({filteredSurebets.length})
                </h2>
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                  Live Updates Active
                </div>
              </div>

              {/* Data Grid Header */}
              <div className="hidden md:grid grid-cols-5 gap-4 px-6 py-3 bg-slate-100 rounded-xl text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                <div className="col-span-1">Profit</div>
                <div className="col-span-2 italic font-serif">Event & Market</div>
                <div className="col-span-1">Bookmakers</div>
                <div className="col-span-1 text-right">Actions</div>
              </div>

              <div className="space-y-3">
                <AnimatePresence mode="popLayout">
                  {filteredSurebets.map((sb) => (
                    <motion.div
                      key={sb.id}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden group"
                    >
                      <div className="p-4 md:p-6 grid grid-cols-1 md:grid-cols-5 gap-4 items-center">
                        {/* Profit Column */}
                        <div className="md:col-span-1 flex flex-row md:flex-col items-center md:items-start justify-between md:justify-center gap-1">
                          <div className="flex flex-col">
                            <span className="text-3xl font-mono font-black text-emerald-600 tracking-tighter leading-none">
                              {sb.profit.toFixed(2)}%
                            </span>
                            <div className="flex items-center gap-1 mt-1">
                              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                              <span className="text-[9px] font-black text-emerald-600 uppercase tracking-widest">Live ROI</span>
                            </div>
                          </div>
                        </div>

                        {/* Event Column */}
                        <div className="md:col-span-2 space-y-1">
                          <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
                            <Globe className="w-3 h-3" />
                            {sb.league}
                          </div>
                          <h3 className="font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
                            {sb.event}
                          </h3>
                          <div className="flex items-center gap-3">
                            <span className="px-2 py-0.5 bg-slate-100 rounded text-[10px] font-bold text-slate-600 uppercase">
                              {sb.market}
                            </span>
                            <span className="flex items-center gap-1 text-[10px] text-slate-400">
                              <Clock className="w-3 h-3" />
                              {new Date(sb.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                        </div>

                        {/* Bookmakers Column */}
                        <div className="md:col-span-1 space-y-2">
                          {sb.outcomes.map((outcome, idx) => (
                            <div key={idx} className="flex items-center justify-between text-xs">
                              <span className="text-slate-500 font-medium">{outcome.bookmaker}</span>
                              <span className="font-mono font-bold text-slate-900 bg-slate-50 px-1.5 rounded border border-slate-100">
                                {outcome.odds.toFixed(2)}
                              </span>
                            </div>
                          ))}
                        </div>

                        {/* Actions Column */}
                        <div className="md:col-span-1 flex md:flex-col gap-2 justify-end">
                          <button 
                            onClick={() => setSelectedSurebet(sb)}
                            className="flex-1 md:w-full flex items-center justify-center gap-2 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition-colors"
                          >
                            <CalcIcon className="w-3.5 h-3.5" />
                            Calculate
                          </button>
                          <button className="p-2 border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors group/btn">
                            <ChevronRight className="w-4 h-4 text-slate-400 group-hover/btn:text-slate-900 transition-colors" />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>

                {!user?.is_premium && (
                  <div className="relative p-12 bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200 text-center space-y-6 overflow-hidden">
                    <div className="absolute inset-0 bg-white/60 backdrop-blur-[4px] rounded-3xl" />
                    <div className="relative z-10 max-w-sm mx-auto">
                      <div className="w-16 h-16 bg-white rounded-2xl shadow-xl flex items-center justify-center mx-auto mb-6 text-emerald-600">
                        <Lock className="w-8 h-8" />
                      </div>
                      <h3 className="text-2xl font-black text-slate-900 tracking-tight">Access Restricted</h3>
                      <p className="text-slate-500 text-sm leading-relaxed">
                        Free accounts are limited to one high-value opportunity per day. 
                        Unlock <strong>20+ daily surebets</strong> and maximize your earnings.
                      </p>
                      <div className="pt-4">
                        <button 
                          onClick={() => setShowUpgradeModal(true)}
                          className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-black text-lg hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-600/30 hover:-translate-y-1 active:scale-95"
                        >
                          Upgrade to Premium
                        </button>
                        <p className="text-[10px] text-slate-400 mt-4 uppercase tracking-widest font-bold">Instant Activation Available</p>
                      </div>
                    </div>
                  </div>
                )}

                {!loading && filteredSurebets.length === 0 && (
                  <div className="py-20 text-center space-y-4">
                    <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-300">
                      <Search className="w-8 h-8" />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900">No opportunities found</h3>
                      <p className="text-slate-500 text-sm">Try adjusting your filters or check back later.</p>
                    </div>
                  </div>
                )}
              </div>
            </section>
          </div>
        )}
      </main>

      {/* Calculator Modal */}
      <AnimatePresence>
        {selectedSurebet && (
          <ArbitrageCalculator 
            outcomes={selectedSurebet.outcomes} 
            onClose={() => setSelectedSurebet(null)} 
          />
        )}
      </AnimatePresence>

      {/* Auth Modal */}
      <AnimatePresence>
        {authModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden"
            >
              <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                <h2 className="text-xl font-bold">
                  {authModal === 'login' ? 'Welcome Back' : 
                   authModal === 'signup' ? 'Create Account' : 
                   authModal === 'forgot' ? 'Reset Password' : 'Admin Access'}
                </h2>
                <button onClick={() => setAuthModal(null)} className="p-2 hover:bg-slate-100 rounded-full"><X className="w-5 h-5" /></button>
              </div>
              <form onSubmit={handleAuth} className="p-6 space-y-4">
                {error && <div className="p-3 bg-red-50 text-red-600 text-sm rounded-lg font-medium">{error}</div>}
                
                {authModal !== 'admin' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Email Address</label>
                    <input 
                      type="email" 
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                )}
                
                {authModal !== 'forgot' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Password</label>
                    <input 
                      type="password" 
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                )}

                {(authModal === 'signup' || authModal === 'forgot') && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Recovery Phrase (e.g. My first pet's name)</label>
                    <input 
                      type="text" 
                      required
                      value={recoveryPhrase}
                      onChange={(e) => setRecoveryPhrase(e.target.value)}
                      className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                      placeholder="Enter a secret phrase to recover your account"
                    />
                  </div>
                )}

                {authModal === 'forgot' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">New Password</label>
                    <input 
                      type="password" 
                      required
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                )}

                <button className="w-full py-3 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 transition-colors">
                  {authModal === 'login' ? 'Log In' : 
                   authModal === 'signup' ? 'Sign Up' : 
                   authModal === 'forgot' ? 'Reset Password' : 'Admin Login'}
                </button>

                {authModal === 'login' && (
                  <div className="flex flex-col gap-2">
                    <button 
                      type="button"
                      onClick={() => setAuthModal('forgot')}
                      className="text-xs text-emerald-600 font-bold hover:underline text-left"
                    >
                      Forgot Password?
                    </button>
                    <p className="text-center text-sm text-slate-500">
                      Don't have an account? 
                      <button 
                        type="button"
                        onClick={() => setAuthModal('signup')}
                        className="text-emerald-600 font-bold hover:underline ml-1"
                      >
                        Sign Up
                      </button>
                    </p>
                  </div>
                )}

                {authModal === 'signup' && (
                  <p className="text-center text-sm text-slate-500">
                    Already have an account? 
                    <button 
                      type="button"
                      onClick={() => setAuthModal('login')}
                      className="text-emerald-600 font-bold hover:underline ml-1"
                    >
                      Log In
                    </button>
                  </p>
                )}

                {authModal === 'forgot' && (
                  <button 
                    type="button"
                    onClick={() => setAuthModal('login')}
                    className="w-full text-xs text-slate-400 hover:text-slate-600"
                  >
                    Back to Login
                  </button>
                )}
                
                {authModal === 'login' && (
                  <button 
                    type="button"
                    onClick={() => setAuthModal('admin')}
                    className="w-full text-xs text-slate-400 hover:text-slate-600 mt-4"
                  >
                    Admin Access
                  </button>
                )}
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Upgrade Modal */}
      <AnimatePresence>
        {showUpgradeModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden"
            >
              <div className="p-6 bg-emerald-600 text-white flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <Zap className="w-6 h-6 fill-current" />
                  <h2 className="text-xl font-bold">Upgrade to Premium</h2>
                </div>
                <button onClick={() => setShowUpgradeModal(false)} className="p-2 hover:bg-emerald-500 rounded-full transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="p-8 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 border-2 border-emerald-100 rounded-2xl bg-emerald-50/50">
                    <div className="text-xs font-bold text-emerald-600 uppercase mb-1">Weekly Plan</div>
                    <div className="text-3xl font-black text-slate-900">$5.00</div>
                    <div className="text-xs text-slate-400">Renewed weekly</div>
                  </div>
                  <div className="p-4 border-2 border-emerald-100 rounded-2xl bg-emerald-50/50">
                    <div className="text-xs font-bold text-emerald-600 uppercase mb-1">Local Price</div>
                    <div className="text-3xl font-black text-slate-900">600 KES</div>
                    <div className="text-xs text-slate-400">Via M-Pesa</div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-bold text-slate-900 flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-emerald-600" />
                    Payment Methods
                  </h3>
                  
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-slate-700">PayPal</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono text-emerald-600">laked243@gmail.com</span>
                        <button 
                          onClick={() => copyToClipboard('laked243@gmail.com', 'paypal')}
                          className="p-1.5 hover:bg-emerald-100 rounded-lg text-emerald-600 transition-colors"
                          title="Copy PayPal Email"
                        >
                          {copied === 'paypal' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                    <div className="h-px bg-slate-200" />
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-slate-700">M-Pesa (SEND MONEY)</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono text-emerald-600">0746034329</span>
                        <button 
                          onClick={() => copyToClipboard('0746034329', 'mpesa')}
                          className="p-1.5 hover:bg-emerald-100 rounded-lg text-emerald-600 transition-colors"
                          title="Copy M-Pesa Number"
                        >
                          {copied === 'mpesa' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 bg-amber-50 rounded-xl border border-amber-100 flex gap-3">
                    <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
                    <p className="text-xs text-amber-800 leading-relaxed">
                      After payment, please share your <strong>Transaction ID</strong> or a screenshot of the confirmation message with our support team via Telegram or WhatsApp. 
                      Once verified, your account will be upgraded to Premium.
                    </p>
                  </div>
                </div>

                <button 
                  onClick={handleUpgrade}
                  className="w-full py-4 bg-emerald-600 text-white font-black rounded-2xl hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-600/20 active:scale-[0.98]"
                >
                  I've Paid - Contact Support to Activate
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Article Modal */}
      <AnimatePresence>
        {articleModal && articleContent && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden"
            >
              <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                <div className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-emerald-600" />
                  <h2 className="text-lg font-bold">{articleContent.title}</h2>
                </div>
                <button onClick={() => setArticleModal(null)} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="p-8 prose prose-slate max-w-none">
                <p className="text-slate-600 leading-relaxed whitespace-pre-wrap">
                  {articleContent.content}
                </p>
              </div>
              <div className="p-6 bg-slate-50 border-t border-slate-100 text-right">
                <button 
                  onClick={() => setArticleModal(null)}
                  className="px-6 py-2 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 transition-colors"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-12 mt-12">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-600" />
              <span className="font-bold text-lg">SureBetKE</span>
            </div>
            <p className="text-sm text-slate-500 leading-relaxed">
              The #1 arbitrage betting tool for East African football fans. 
              We scan 20+ bookmakers to find you guaranteed profit opportunities.
            </p>
          </div>
          
          <div>
            <h4 className="font-bold text-sm uppercase tracking-wider mb-6 flex items-center gap-2">
              <Info className="w-4 h-4 text-slate-400" />
              Quick Links
            </h4>
            <ul className="space-y-3 text-sm text-slate-500">
              <li><button onClick={() => fetchArticle('how-it-works')} className="hover:text-emerald-600 transition-colors">How it Works</button></li>
              <li><button onClick={() => fetchArticle('arbitrage-guide')} className="hover:text-emerald-600 transition-colors">Arbitrage Guide</button></li>
              <li><button onClick={() => fetchArticle('risk-management')} className="hover:text-emerald-600 transition-colors">Risk Management</button></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-sm uppercase tracking-wider mb-6 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-slate-400" />
              Support
            </h4>
            <div className="space-y-3">
              <div className="space-y-2">
                <button 
                  onClick={() => toggleContact('telegram')}
                  className="w-full flex items-center gap-3 p-3 bg-slate-50 rounded-xl hover:bg-emerald-50 hover:text-emerald-700 transition-all group text-left"
                >
                  <Send className="w-5 h-5 text-slate-400 group-hover:text-emerald-600" />
                  <div className="flex flex-col">
                    <span className="text-xs font-bold">Telegram Support</span>
                    <span className="text-[10px] text-slate-400">
                      {showContacts['telegram'] ? '@Davis_1984' : 'Click to reveal'}
                    </span>
                  </div>
                </button>
                {showContacts['telegram'] && (
                  <a 
                    href="https://t.me/Davis_1984" 
                    target="_blank" 
                    rel="noreferrer"
                    className="block text-center py-2 bg-emerald-600 text-white rounded-xl text-[10px] font-bold hover:bg-emerald-700 transition-colors"
                  >
                    Open Telegram Chat
                  </a>
                )}
              </div>

              <div className="space-y-2">
                <button 
                  onClick={() => toggleContact('whatsapp')}
                  className="w-full flex items-center gap-3 p-3 bg-slate-50 rounded-xl hover:bg-emerald-50 hover:text-emerald-700 transition-all group text-left"
                >
                  <MessageCircle className="w-5 h-5 text-slate-400 group-hover:text-emerald-600" />
                  <div className="flex flex-col">
                    <span className="text-xs font-bold">WhatsApp Support</span>
                    <span className="text-[10px] text-slate-400">
                      {showContacts['whatsapp'] ? '0746034329' : 'Click to reveal'}
                    </span>
                  </div>
                </button>
                {showContacts['whatsapp'] && (
                  <a 
                    href="https://wa.me/254746034329" 
                    target="_blank" 
                    rel="noreferrer"
                    className="block text-center py-2 bg-emerald-600 text-white rounded-xl text-[10px] font-bold hover:bg-emerald-700 transition-colors"
                  >
                    Open WhatsApp Chat
                  </a>
                )}
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-sm uppercase tracking-wider mb-6">Responsible Betting</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Betting involves risk. Arbitrage reduces risk but requires precision. 
              Always verify odds before placing bets. Must be 18+ to use this service.
            </p>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 pt-8 mt-12 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-slate-400">© 2026 SureBetKE. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <button onClick={() => setAuthModal('admin')} className="text-[10px] text-slate-300 hover:text-slate-500 uppercase tracking-widest font-bold">Admin Portal</button>
          </div>
        </div>
      </footer>
    </div>
  );
}
