import React, { useState, useEffect } from 'react';
import { Calculator, ExternalLink, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Outcome, CalculatorResult } from '../types';

interface ArbitrageCalculatorProps {
  outcomes: Outcome[];
  onClose: () => void;
}

export const ArbitrageCalculator: React.FC<ArbitrageCalculatorProps> = ({ outcomes, onClose }) => {
  const [totalStake, setTotalStake] = useState<number>(1000);
  const [results, setResults] = useState<CalculatorResult | null>(null);

  useEffect(() => {
    const invOddsSum = outcomes.reduce((sum, o) => sum + (1 / o.odds), 0);
    const stakes = outcomes.map(o => (totalStake / (o.odds * invOddsSum)));
    const totalPayout = stakes[0] * outcomes[0].odds;
    const profit = totalPayout - totalStake;
    const profitPercent = (profit / totalStake) * 100;

    setResults({
      stakes,
      totalStake,
      totalPayout,
      profit,
      profitPercent
    });
  }, [totalStake, outcomes]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-200"
      >
        <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center text-emerald-600">
              <Calculator className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black tracking-tight text-slate-900">Arbitrage Calculator</h2>
              <p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest">Stake Distribution</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2.5 hover:bg-slate-200 rounded-xl transition-all active:scale-90">
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        <div className="p-8 space-y-8">
          <div className="space-y-3">
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest">
              Total Investment (KES)
            </label>
            <div className="relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">KES</div>
              <input
                type="number"
                value={totalStake}
                onChange={(e) => setTotalStake(Number(e.target.value))}
                className="w-full text-3xl font-mono font-black pl-14 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none transition-all"
              />
            </div>
          </div>

          <div className="space-y-3">
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest">
              Required Stakes
            </label>
            <div className="space-y-3">
              {outcomes.map((outcome, idx) => (
                <div key={idx} className="flex items-center justify-between p-4 bg-white rounded-2xl border border-slate-100 shadow-sm hover:border-emerald-200 transition-colors group">
                  <div className="flex items-center gap-4">
                    <div className="w-8 h-8 bg-slate-50 rounded-lg flex items-center justify-center text-[10px] font-black text-slate-400 group-hover:bg-emerald-50 group-hover:text-emerald-600 transition-colors">
                      {outcome.label}
                    </div>
                    <div>
                      <div className="text-sm font-black text-slate-900">{outcome.bookmaker}</div>
                      <div className="text-[10px] text-slate-400 uppercase font-bold tracking-tighter">Odds: {outcome.odds.toFixed(2)}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-mono font-black text-emerald-600">
                      {results?.stakes[idx].toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </div>
                    <div className="text-[10px] text-slate-400 uppercase font-bold">Stake</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {results && (
            <div className="grid grid-cols-2 gap-4 pt-4">
              <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100">
                <div className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Net Profit</div>
                <div className="text-2xl font-mono font-black text-slate-900">
                  +{results.profit.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                </div>
              </div>
              <div className="p-5 bg-emerald-600 rounded-2xl text-white shadow-xl shadow-emerald-600/20">
                <div className="text-[10px] text-emerald-100 font-black uppercase tracking-widest mb-1">ROI</div>
                <div className="text-2xl font-mono font-black">
                  {results.profitPercent.toFixed(2)}%
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="p-8 bg-slate-50/50 border-t border-slate-100">
          <button
            onClick={onClose}
            className="w-full py-4 bg-slate-900 text-white font-black rounded-2xl hover:bg-slate-800 transition-all shadow-xl shadow-slate-900/20 active:scale-[0.98]"
          >
            Done
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
};
