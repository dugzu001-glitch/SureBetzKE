export const BOOKMAKERS_DATA = [
  { name: "Betika", url: "https://www.betika.com.gh/?token=xJyrhKWiFU0igIQ18AwJ6WNd7ZgqdRLk" },
  { name: "Odibets", url: "https://odibets.com/" },
  { name: "Kwikbet", url: "https://kwikbet.co.ke/" },
  { name: "Bangbet", url: "https://www.bangbet.com/ke-m" },
  { name: "Mozzartbet", url: "https://www.mozzartbet.co.ke/" },
  { name: "Sportybet", url: "https://www.sportybet.com/ke/" },
  { name: "22bet", url: "https://22bet.co.ke/" },
  { name: "Helabet", url: "https://helabetke.com/" },
  { name: "Afropari", url: "https://afropari8308876.top/tag=d_3715481m_70055c_" },
  { name: "Chezacash", url: "https://www.chezacash.com/#/" },
  { name: "Stake", url: "https://stake.com/sports/home" },
  { name: "Paripesa", url: "https://bonus.paripesa.cool/getapp-3.2/index.html?tag=d_2702345m_45611c_&lang=en" },
  { name: "Linebet", url: "https://linebet.com/en?tag=d_2676145m_22611c_" },
  { name: "1xbet", url: "https://1xbet.co.ke/en?tag=d_747755m_97c_23" },
  { name: "BC.Game", url: "https://bcgame.top/?stag=43156_6997cbe651c40273753592b5&spin=true&i=4cxse6dr&utm_source=4cxse6dr" },
  { name: "888sport", url: "https://www.888sport.com/spt/betget-offer/" },
  { name: "SaharaGames", url: "https://ke.saharagames.com/en?t=prematch" },
  { name: "Meridianbet", url: "https://promotion.meridianbet.com/50ewelcomebonus?a=2446&c=1" },
  { name: "Sportpesa", url: "https://www.ke.sportpesa.com/en/sports-betting/football-1/" },
  { name: "1win", url: "https://1win.or.ke/" },
  { name: "Betway", url: "https://betway.com/g/en/sports" },
  { name: "Pinnacle", url: "https://www.pinnacle.com/en/" }
];

export const BOOKMAKERS = BOOKMAKERS_DATA.map(b => b.name);


export const MARKETS = [
  "1X2",
  "Over/Under 2.5",
  "BTTS",
  "Double Chance",
  "Draw No Bet"
];
