export interface Outcome {
  label: string;
  bookmaker: string;
  odds: number;
  url: string;
}

export interface Surebet {
  id: string;
  event: string;
  league: string;
  startTime: string;
  market: string;
  profit: number;
  outcomes: Outcome[];
}

export interface CalculatorResult {
  stakes: number[];
  totalStake: number;
  totalPayout: number;
  profit: number;
  profitPercent: number;
}
